package com.isyriux.divinerod.items;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;

public class Misc extends Item {
    public Misc() {
        super(new Item.Properties().group(ItemGroup.MISC));
    }
}
